import './App.css'
import ReviewApp from './ReviewProject/ReviewApp'
import 'bootstrap/dist/css/bootstrap.min.css';

export default function App() {
  return (
    <>
     <ReviewApp/>
    </>
  )
}
